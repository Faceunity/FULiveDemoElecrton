# FULiveElectronDemo

## 中文

FULiveElectronDemo 是 Windows 平台上，集成相芯人脸跟踪及视频特效开发包（简 Nama SDK）的集成示例。

目前仅集成美颜模块，其它模块包括面部跟踪、Animoji、道具贴纸、AR面具、表情识别、音乐滤镜、背景分割、手势识别、哈哈镜、Avatar等功能将会陆续更新迭代。

### 开发文档

相关文档位于本项目docs目录，包括:

1. [Nama_Demo_运行文档.md](./docs/Windows_Nama_Demo_运行文档.md)，介绍如何运行demo
2. [Nama_SDK_集成指导文档.md](./docs/Windows_Nama_SDK_集成指导文档.md)，介绍如何在宿主程序中集成Nama SDK。   
3. [Nama_C_API_参考文档.md](./docs/Nama_C_API_参考文档.md)，Nama SDK C接口定义。  
4. 由于git限制大小，MAC用户请手动解压ThirdParty\Mac\ffmpeg\lib\libavcodec.zip

## English

FULiveElectronDemo is an integration example, that integrates Faceunity's Face AR SDK (aka Nama SDK) on Windows platform.

At present, only the Face Beautification is integrated. Other interesting features of Faceunity's Face AR SDK,such as Face landmarks and expressions tracking, Animoji, Stickers, AR Mask, Face Tranfer, Musical Filters, Background Segmentation, Hand Gestures Detection, Face Warping, Live Photo, etc.will be updated gradually.



### Documents

Related documents locate in __./docs__ directory, including:   

1. [Windows_Nama_Demo_Guide.md](./docs/Windows_Nama_Demo_Guide.md), this illustrate how to run this demo.  
2. [Windows_Nama_SDK_Integration_Guide.md](./docs/Windows_Nama_SDK_Integration_Guide.md) , this illustrate how to integrate the SDK into the host app.   
3. [Nama_C_API_Reference.md](./docs/Nama_C_API_Reference.md)，this show SDK's  C API Reference.  
